//
//  NavigationViewController.swift
//  harvestDC
//
//  Created by Johanna Ostrich on 3/15/15.
//  Copyright (c) 2015 Johanna Ostrich. All rights reserved.
//

import UIKit

class NavigationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

//        self.navigationController.navigationBar.barStyle = UIBarStyle.Black
//        self.navigationBar.tintColor = UIColor.whiteColor()
        
    
        
    }


}
